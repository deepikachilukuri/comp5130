import "./App.css";
import pic from './images/Foodmart logo.png'
import { Link } from "react-router-dom";
function App() {
  return (
    <div className="App">
      <div className="header-box">
        <div className="header-logo">
          <img src={pic} alt="logo" style={{width:"120px", height:'100px'}}/>
        </div>
        <div className="header-basic">
        <Link to="/" style={{color:'white', textDecorationLine:'none'}}>Home</Link>
          <Link to="/payment" style={{color:'white', textDecorationLine:'none'}}>Payment</Link>
          <p>Order Online</p>
          <p>Call Center</p>
          <p style={{marginLeft:'40px'}}>Cart</p>
        </div>
      </div>
      <div className="body-box">
        <div className="body-header">
          <div className="body-headerBox">
            <p style={{fontSize:'2.8rem', fontWeight:'700', color:'white'}}>Tasty Food, Tasty Life</p>
            <p style={{color:'white', fontWeight:'500'}}>Enjoy every dish prepared from well sorted ingredients and made with all the love to cherish life</p>
            <div className="mini-menu">
              <p style={{fontWeight:'700', color:'yellow'}}>Snacks</p>
              <p style={{fontWeight:'700', color:'yellow'}}>Burgers</p>
              <p style={{fontWeight:'700', color:'yellow'}}>Sandwiches</p>
              <p style={{fontWeight:'700', color:'yellow'}}>Pizza</p>
              <p style={{fontWeight:'700', color:'yellow'}}>Shakes</p>
              <p style={{fontWeight:'700', color:'yellow'}}>Drinks</p>
            </div>
          </div>
        </div>
        <div className="body-menu">
          <div style={{height:'40px', textAlign:'left'}}>
            <p style={{marginLeft:'20px', fontSize:'1.4rem', fontWeight:'700', color:'red', marginTop:'3px'}}>Top Order</p>
          </div>
          <div className="food-holder">
          <div className="food-box">
            <div className="food-boxImg"></div>
            <div className="food-boxDescription">
              <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Burger</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$10.00</p>
            </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>French Fries</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$8.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Tacos</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$9.75</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Sandwich</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$7.99</p>
          </div>
          </div>
          </div>
        </div>
        
        {/* The second list in the menu */}
        <div className="body-menu">
        <div style={{height:'40px', textAlign:'left'}}>
            <p style={{marginLeft:'20px', fontSize:'1.4rem', fontWeight:'700', color:'red', marginTop:'3px'}}>Pizzas</p>
          </div>
          <div className="food-holder">
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Mexican Pizza</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$15.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Pepperoni Pizza</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$12.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Chicken BBQ Pizza</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$13.50</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Cheese Pizza</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$12.75</p>
          </div>
          </div>
          </div>
        </div>

       {/* The third food list */}

        <div className="body-menu">
        <div style={{height:'40px', textAlign:'left'}}>
            <p style={{marginLeft:'20px', fontSize:'1.4rem', fontWeight:'700', color:'red', marginTop:'3px'}}>Diner Speciality</p>
          </div>
          <div className="food-holder">
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Meat Steak</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$17.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Chilaquiles w/steak</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$15.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Buffalo wings</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$9.00</p>
          </div>
          </div>
          <div className="food-box">
          <div className="food-boxImg"></div>
          <div className="food-boxDescription">
          <p style={{fontWeight:'600', fontSize:'1.3rem'}}>Steak Skillet</p>
              <p style={{fontSize:'0.9rem', textAlign:'center'}}>Double layered burger with cheese and onion toppings</p>
              <p style={{fontSize:'1.2rem'}}>$12.00</p>
          </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;

import React from 'react'
import './App.css'
import './Payment.css'
import pic from './images/Foodmart logo.png'
import { Link } from "react-router-dom";

const Payments = () => {
  return (
    <>
    <div className="header-box">
        <div className="header-logo">
          <img src={pic} alt="logo" style={{width:"120px", height:'100px'}}/>
        </div>
        <div className="header-basic">
        <Link to="/" style={{color:'white', textDecorationLine:'none'}}>Home</Link>
        <Link to="/payment" style={{color:'white', textDecorationLine:'none'}}>Payment</Link>
          <p>Order Online</p>
          <p>Call Center</p>
          <p style={{marginLeft:'40px'}}>Cart</p>
        </div>
      </div>
      <div className='payment-body'>
      <div className='payment-box'>
        <div className='delivery'>
            <p style={{marginLeft:'20px'}}>1. Delivery Location</p>
            <p style={{marginLeft:'30px'}}>Enter Address</p>
            <input className='form-input' style={{marginLeft:'30px'}}/>
        </div>
        <div className='payment-method'>
        <p style={{marginLeft:'20px'}}>2. Payment Method</p>
            <p style={{marginLeft:'30px'}}>Bank Payment</p>
            <p style={{marginLeft:'40px', marginTop:'10px'}}>Cardholder name</p>
            <input className='form-input' style={{marginLeft:'40px'}}/>
            <div style={{display:'flex', columnGap:'10px', marginLeft:'40px', marginTop:'10px'}}>
            <p >Card number</p>
            <p style={{marginLeft:'160px'}}>CVV</p>
            <p style={{marginLeft:'80px'}}>Date</p>
            </div>
            <div style={{display:'flex', columnGap:'30px'}}>
            <input className='form-input' style={{marginLeft:'40px', width:'200px'}}/> 
            <input className='form-input' style={{width:'80px'}}/> 
            <input className='form-input' style={{width:'100px'}}/> 
            </div>
        </div>
        <div className='special-note' style={{border:'none'}}>
        <p style={{marginLeft:'20px'}}>3. Special Note</p>
            <input className='form-input' style={{marginLeft:'30px', height:'120px', width:'70%'}}/>
        </div>
      </div>
      <div className='payment-box'>
        <p style={{marginLeft:'40px', marginTop:'40px', fontSize:'1.8rem', fontWeight:'600'}}>Payment Summary</p>
        <div className='payment-details'>
            <div style={{height:'50px', display:'flex', columnGap:'150px', justifyContent:'center', fontSize:'0.9rem'}}>
                <p>Total amount</p>
                <p>$50.00</p>
            </div>
            <div style={{height:'50px', display:'flex', columnGap:'150px', justifyContent:'center', fontSize:'0.9rem'}}>
                <p>Tax amount</p>
                <p>$5.75</p>
            </div>
            <div style={{height:'50px', display:'flex', columnGap:'150px', justifyContent:'center', fontSize:'0.9rem'}}>
                <p>Total Balance</p>
                <p>$55.75</p>
            </div>
            <div style={{height:'50px', width:'60%', backgroundColor:'blue', borderRadius:'8px', marginLeft:'auto', marginRight:'auto', marginTop:'60px', textAlign:'center', display:'flow-root'}}>
                <p style={{color:'white', marginTop:'15px', fontSize:'0.8rem', fontWeight:'700'}}>Confirm Order</p>
            </div>
        </div>
      </div>
      </div>
      </>
  )
}

export default Payments